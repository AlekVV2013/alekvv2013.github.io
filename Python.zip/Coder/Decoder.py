import base64
import time
import shelve

code = shelve.open("coded_file")
for a in code["coded_string"]:
    code_str = str(a)
code.close()
print("Зашифрованный текст = " + code_str)

base64_string = code_str
base64_bytes = base64_string.encode("ascii")

string_bytes = base64.b64decode(base64_bytes)
string = string_bytes.decode("ascii")
print("Расшифровываю...")
time.sleep(2)
print("Расшифровка = " + string)
yes = input("Записать в txt? (yes\dont)\n")
if yes == "yes":
    txt = open("out.txt", "w")
    txt.write(string)
    print("Смотрите файл out.txt")
    input("Нажмите Enter чтобы выйти")
else:
    print("Окей")
    input("Нажмите Enter чтобы выйти")
