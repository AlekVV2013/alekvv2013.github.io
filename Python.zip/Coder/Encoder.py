import base64
import time
import shelve

string = input("Что переписать в закодированный .dat?\n")
string_bytes = string.encode("ascii")

base64 = base64.b64encode(string_bytes)
base64_out = base64.decode("ascii")

print("Закодированный string = " + base64_out)
print("Записываю в .dat файл")
time.sleep(2)

code_dat = shelve.open("coded_file")
code_dat["coded_string"] = [base64_out]
print("Готово")