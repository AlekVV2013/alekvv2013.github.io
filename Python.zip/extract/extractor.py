import zipfile

file = str(input(".zip файл: "))
path = str(input("путь выгрузки: "))

with zipfile.ZipFile(file, "r") as zf:
    zf.extractall(path)
