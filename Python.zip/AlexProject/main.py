import numpy as np
import time
import os


def clear():
    os.system("cls")


def loading(number, nu, t):
    arr = np.full((nu, number), "_")
    clear()
    print("Загрузка...")
    print(arr, "\a")
    time.sleep(t)
    if debug == "y":
        for u in range(nu):
            for i in range(number):
                tu = t * ((number * u) + i)
                ti = t * number * nu
                te = ti - tu
                arr[u, i] = "O"
                print("Загрузка...")
                print("Осталось примерно ", te, " секунд")
                print(arr, "\a")
                time.sleep(t)
    else:
        for u in range(nu):
            for i in range(number):
                tu = t * ((number * u) + i)
                ti = t * number * nu
                ty = ti - tu
                te = round(ty, 1)
                clear()
                arr[u, i] = "O"
                print("Загрузка...")
                print("Осталось примерно ", te, " секунд")
                time.sleep(t)


debug = input("Показывать поле загрузки(y/что угодно): ")

clear()
input("Нажмите Enter чтобы запустить Hello World!...")

loading(15, 15, 0.1)
clear()
print("Hello World!")
