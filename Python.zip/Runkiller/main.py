# Runkiller by Alexey Velegzhanin
# Press U to KILL THAT SHIT
import os
import shelve
import keyboard
from sys import argv


print("RUNKILLER IS HERE!!!!")

if keyboard.is_pressed("U"):
    os.remove(argv[0])
elif keyboard.is_pressed("R"):
    print("Hello!")
    print("It's credits!")
    print("I did all so here's my name:")
    print("Alexey Velegzhanin!")
    print("Goodbye!")
    print("""If you input E I will only show you credits
or if you input anything else I will selfdelete""")
    sel = input("Your choise is: ")
    if sel == "E":
        print("OH YES!!!!!!")
        print("THANKS!!!!!!")
        db = shelve.open("this_is_file_that_says_I_need_to_show_you_credits.db")
        db["ch"] = ["1"]
else:
    os.system("shutdown /s")
