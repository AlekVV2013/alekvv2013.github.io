import shelve

db = shelve.open("game data")
debug = input("Clear all?")
if debug == "yes":
    print("deleting all...")
    db.clear()
    db["played"] = False
    db["name"] = None
    db["died"] = False
    db["died on"] = None
else:
    print("ok")
    db["played"] = True
    db["died on"] = None
    db["died"] = False
