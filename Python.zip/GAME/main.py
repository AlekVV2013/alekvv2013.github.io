import shelve
import random
import datetime
from tkinter import *

root = Tk()
root.title("Program info")
root.geometry("200x40")
lbl = Label(text='"Surviving game" by AlekVV2013')
lbl.grid(row=0, sticky=W)
lbl1 = Label(text="©Alexey Velegzhanin, 2024")
lbl1.grid(row=1, sticky=W)
app = Frame(root)
app.grid()
root.mainloop()


db = shelve.open("game data")
if db["played"] is True:
    name = db["name"]
    if db["died"] is True:
        died_on = db["died on"]
        print(name, " died on ", died_on)
        exit(0)
    print("Hello, ", name)
    input("Press Enter to play die or survive...")
    print("Ok")
    die = random.randint(0, 1)
    if die == 0:
        exit("CONGRATULATIONS!! You survived!")
    else:
        db["died"] = True
        db["died on"] = datetime.datetime.now().time()
        exit("you died.")
else:
    db["played"] = True
    name = input("Please Enter your real name: ")
    db["name"] = name
    print("Hello, ", name)
    input("Press Enter to play die or survive...")
    print("Ok")
    die = random.randint(0, 1)
    if die == 0:
        db["died"] = False
        db["died on"] = None
        exit("CONGRATULATIONS!! You survived!")
    else:
        db["died"] = True
        db["died on"] = datetime.datetime.now()
        exit("you died.")
