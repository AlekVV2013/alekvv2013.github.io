import shelve
import time
import os

os.system("color 2")
code = shelve.open("code", "c")
print("FBI SECRET ARCHIVE TERMINAL")
pas = int(input("Password: "))

if pas == code["very_secret_access_code"]:
    print("-----ACCESS GRANTED-----")
    print("-----ACCESSING DATABASE-----")
    time.sleep(1)
    print(os.system("dir /s"))
    print("\n-----ACCESSED-----")
    time.sleep(1)
    print("-----EXTRACTING DATABASE-----")
    time.sleep(1)
    print(os.system("dir /s"))
    print("\n-----EXTRACTED-----")
    time.sleep(1)
    print("-----FINDED RECORDS-----")
    for key in code:
        print(key, " - ", code[key])
    input("Press Enter to exit")
else:
    print("""-----ACCESS DENIED-----
-----GO TO HELL HACKER-----""")
    input("Press Enter to go to hell")
