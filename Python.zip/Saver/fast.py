import shelve

shelv = shelve.open("code", "w")
shelv.clear()
shelv["very_secret_access_code"] = 2013
shelv["info"] = "some secret info", "another secret info"
shelv["something"] = "something very secret"
