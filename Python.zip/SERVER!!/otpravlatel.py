import socket

print("""Создано AlekVV2013
------------------------------
        Комунникатор!
v1.0.1
------------------------------
Модуль-отправлятель""")
print()

host_con = input("К какому ip вы ходите подключится: ")
port_con = int(input("К какому порту вы хотите подключится: "))

print("Подключение...")
HOST = host_con  # The server's hostname or IP address
PORT = port_con  # The port used by the server

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    try:
        s.connect((HOST, PORT))
    except TimeoutError:
        exit("Компьютер-получатель слишком долго не отвечал на запрос соединения")
    print("Подключено!")
    while True:
        message = input("Введите сообщение для отправки: ")
        s.sendall(bytes(message, "utf-8"))
