import socket
import random

print("""Создано AlekVV2013
------------------------------
        Комунникатор!
v1.0.1
------------------------------
Модуль-получатель""")
print()

print("Определение ip адреса...")
HOST = socket.gethostbyname(socket.gethostname())
select = input("Вы хотите вручную назначить порт для подключения?(y/n):")
if select == "y":
    PORT = input("Какой порт для подключения вы хотите использовать(<1024, >65535):")
else:
    PORT = random.randint(55000, 65535)
print("Ip получен!")
print("Ваш ip для подключения: ", HOST)
print("Ваш порт для подключения: ", PORT)

print("Запуск сервера...")
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    while True:
        s.listen()
        print("""Сервер готов!
        Ожидание подключения...""")
        conn, addr = s.accept()
        with conn:
            print(f"Подключен к {addr}!")
            while True:
                data = conn.recv(1024)
                if not data:
                    break
                print("Получено сообщение: ", str(data))
