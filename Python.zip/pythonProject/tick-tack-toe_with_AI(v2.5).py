import numpy as np

numb = 0
print('игра "Крестики Нолики"')
print('Создано Алексеем Велегжаниным')
roun = 0
arr = np.array([["_", "_", "_"], ["_", "_", "_"], ["_", "_", "_"]])
while True:
    numb = numb + 1
    if numb == 10:
        exit("Ничья!!!!!!")
    for i in range(3):
        inty = list(arr[i, :])
        intx = list(arr[:, i])
        if inty == ["O", "O", "O"]:
            exit("Нолики победили")
        if intx == ["O", "O", "O"]:
            exit("Нолики победили")
        if arr[0, 0] == "O" and arr[1, 1] == "O" and arr[2, 2] == "O":
            exit("Нолики победили")
        if arr[0, 2] == "O" and arr[1, 1] == "O" and arr[2, 0] == "O":
            exit("Нолики победили")
    for i in range(3):
        inty = list(arr[i, :])
        intx = list(arr[:, i])
        if inty == ["X", "X", "X"]:
            exit("Крестики победили")
        if intx == ["X", "X", "X"]:
            exit("Крестики победили")
        if arr[0, 0] == "X" and arr[1, 1] == "X" and arr[2, 2] == "X":
            exit("Крестики победили")
        if arr[0, 2] == "X" and arr[1, 1] == "X" and arr[2, 0] == "X":
            exit("Крестики победили")
    print(arr)
    if roun == 0:
        r = int(input("Введите номер ряда куда поставить нолик: "))
        c = int(input("Введите номер столбца куда поставить нолик: "))
        if arr[r, c] != "_":
            print("Но Но Но чел, Но Но Но")
            print("Пропускаешь ход!!")
            pass
        else:
            arr[r, c] = "O"
            roun = 1
    else:
        r = int(input("Введите номер ряда куда поставить крестик: "))
        c = int(input("Введите номер столбца куда поставить крестик: "))
        if arr[r, c] != "_":
            print("Но Но Но чел, Но Но Но")
            print("Пропускаешь ход!!")
            pass
        else:
            arr[r, c] = "X"
            roun = 0
