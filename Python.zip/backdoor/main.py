import os
import time

print("""Консоль!!  v0.0.2
(здесь очень много багов!!)
Создано AlekVV2013
Напишите help_pr чтобы прочитать внутренние команды""")

while True:
    comm = input(">>>  ")
    time.sleep(1)
    if comm == "help_pr":
        print("quit_pr --- выйти из программы")
        time.sleep(1)
    elif comm == "quit_pr":
        exit(0)
    else:
        out = os.system(comm)
        print(out)
        time.sleep(1)
